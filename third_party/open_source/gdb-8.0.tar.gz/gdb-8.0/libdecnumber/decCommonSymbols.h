#if !defined(DECCOMMONSYMBOLS)
#define DECCOMMONSYMBOLS

#ifdef IN_LIBGCC2
#define DECCOMBFROM __decCOMBFROM
#define DECCOMBMSD __decCOMBMSD
#endif

#endif
